import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:mkrempire/app/controllers/kyc_controller.dart';
import 'package:mkrempire/config/app_colors.dart';
import 'package:mkrempire/resources/widgets/custom_app_bar.dart';
import 'package:mkrempire/resources/widgets/custom_app_button.dart';
import 'package:mkrempire/resources/widgets/custom_textfield.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:pin_code_text_field/pin_code_text_field.dart';

class KYCScreen extends StatefulWidget {
  const KYCScreen({super.key});

  @override
  State<KYCScreen> createState() => _KYCScreenState();
}

class _KYCScreenState extends State<KYCScreen> {
  final KycController controller = Get.put(KycController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'KYC Verification',
      ),
      body: SafeArea(
          child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 18.0.w),
        child: Column(
          children: [
            Text(
              'Kindly provide your Bank Verification Number (BVN) to complete your KYC verification.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            Gap(50),
            Obx(
              () => CustomTextField(
                hintText: 'Enter your BVN',
                controller: controller.bvnController.value,
              ),
            ),
            Gap(80),
            Obx(() => Container(
                  child: CustomAppButton(
                      isLoading: controller.isSubmitting.value == true,
                      bgColor: controller.isBvnEmpty.value
                          ? Get.isDarkMode
                              ? AppColors.secondaryColor.withOpacity(0.3)
                              : AppColors.mainColor.withOpacity(0.3)
                          : Get.isDarkMode
                              ? AppColors.secondaryColor
                              : AppColors.mainColor,
                      textColor: Colors.white,
                      onTap: controller.isBvnEmpty.value
                          ? null
                          : () {
                              controller.submitKyc(
                                  kycData: controller.bvnController.value.text,
                                  onPressed: () async {
                                    Get.back();
                                    await showModalBottomSheet(
                                        context: context,
                                        builder: (context) {
                                          return SizedBox(
                                              width: double.infinity,
                                              height: 0.5.sh,
                                              child: Padding(
                                                padding: EdgeInsets.all(18.0),
                                                child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Text(
                                                        'Confirm your Details',
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .bodyMedium,
                                                      ),
                                                      Gap(20),
                                                      Container(
                                                          width: double
                                                              .infinity,
                                                          height: 0.05.sh,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      16.0.w,
                                                                  vertical:
                                                                      8.h),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Get
                                                                    .isDarkMode
                                                                ? AppColors
                                                                    .black70
                                                                    .withAlpha(
                                                                        100)
                                                                : AppColors
                                                                    .bgColor
                                                                    .withAlpha(
                                                                        100),
                                                          ),
                                                          child: Text(
                                                              controller
                                                                  .firstName
                                                                  .value,
                                                              style: Theme.of(
                                                                      context)
                                                                  .textTheme
                                                                  .bodyMedium)),
                                                      Gap(10),
                                                      Container(
                                                          width: double
                                                              .infinity,
                                                          height: 0.05.sh,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      16.0.w,
                                                                  vertical:
                                                                      8.h),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Get
                                                                    .isDarkMode
                                                                ? AppColors
                                                                    .black70
                                                                    .withAlpha(
                                                                        100)
                                                                : AppColors
                                                                    .bgColor
                                                                    .withAlpha(
                                                                        100),
                                                          ),
                                                          child: Text(
                                                              controller
                                                                  .lastName
                                                                  .value,
                                                              style: Theme.of(
                                                                      context)
                                                                  .textTheme
                                                                  .bodyMedium)),
                                                      Gap(10),
                                                      Container(
                                                          width: double
                                                              .infinity,
                                                          height: 0.05.sh,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      16.0.w,
                                                                  vertical:
                                                                      8.h),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Get
                                                                    .isDarkMode
                                                                ? AppColors
                                                                    .black70
                                                                    .withAlpha(
                                                                        100)
                                                                : AppColors
                                                                    .bgColor
                                                                    .withAlpha(
                                                                        100),
                                                          ),
                                                          child: Text(
                                                              controller
                                                                  .phoneNumber
                                                                  .value,
                                                              style: Theme.of(
                                                                      context)
                                                                  .textTheme
                                                                  .bodyMedium)),
                                                      Gap(10),
                                                      Container(
                                                          width: double
                                                              .infinity,
                                                          height: 0.05.sh,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      16.0.w,
                                                                  vertical:
                                                                      8.h),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Get
                                                                    .isDarkMode
                                                                ? AppColors
                                                                    .black70
                                                                    .withAlpha(
                                                                        100)
                                                                : AppColors
                                                                    .bgColor
                                                                    .withAlpha(
                                                                        100),
                                                          ),
                                                          child: Text(
                                                              controller
                                                                  .dob.value,
                                                              style: Theme.of(
                                                                      context)
                                                                  .textTheme
                                                                  .bodyMedium)),
                                                      Gap(50),
                                                      Container(
                                                        child: CustomAppButton(
                                                          bgColor: Get
                                                                  .isDarkMode
                                                              ? AppColors
                                                                  .secondaryColor
                                                              : AppColors
                                                                  .mainColor,
                                                          onTap: () {
                                                            controller
                                                                .sendOtp(() {
                                                              Get.back();
                                                              Get.back();
                                                              showDialog(
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return AlertDialog(
                                                                      contentPadding:
                                                                          EdgeInsets.all(
                                                                              32.sp),
                                                                      content:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.min,
                                                                        children: [
                                                                          Text(
                                                                            'Enter Code',
                                                                            style:
                                                                                Theme.of(context).textTheme.bodySmall,
                                                                          ),
                                                                          Gap(30),
                                                                          PinCodeTextField(
                                                                            maxLength:
                                                                                5,
                                                                            pinBoxWidth:
                                                                                40.w,
                                                                            pinBoxHeight:
                                                                                50.h,
                                                                            pinBoxRadius:
                                                                                10,
                                                                            pinBoxColor:
                                                                                AppColors.black70,
                                                                            pinBoxBorderWidth:
                                                                                1,
                                                                            pinBoxOuterPadding:
                                                                                EdgeInsets.symmetric(horizontal: 4.w),
                                                                            pinTextStyle:
                                                                                TextStyle(fontSize: 20.sp),
                                                                            pinTextAnimatedSwitcherTransition:
                                                                                ProvidedPinBoxTextAnimation.scalingTransition,
                                                                            pinTextAnimatedSwitcherDuration:
                                                                                Duration(milliseconds: 300),
                                                                            defaultBorderColor:
                                                                                Colors.transparent,
                                                                            hasError:
                                                                                false,
                                                                            onDone:
                                                                                (String otp) async {
                                                                              controller.oTp.value = otp;
                                                                              await controller.verifyOtp(otpCode: controller.oTp.value, pinId: controller.pin_Id.value);
                                                                              // await _nextStep;
                                                                            },
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  });
                                                            });
                                                          },
                                                        ),
                                                      )
                                                    ]),
                                              ));
                                        });
                                  });
                            }),
                ))
          ],
        ),
      )),
    );
  }
}
