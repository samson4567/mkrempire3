class AppConstants {
  static String appName = 'mkrempire';
}
